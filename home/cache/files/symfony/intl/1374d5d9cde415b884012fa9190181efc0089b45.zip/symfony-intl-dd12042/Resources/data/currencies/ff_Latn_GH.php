<?php

return [
    'Names' => [
        'GHS' => [
            'GH₵',
            'GHS',
        ],
    ],
];
