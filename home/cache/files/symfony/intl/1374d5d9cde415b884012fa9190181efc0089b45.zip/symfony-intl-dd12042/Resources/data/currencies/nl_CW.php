<?php

return [
    'Names' => [
        'ANG' => [
            'NAf.',
            'Nederlands-Antilliaanse gulden',
        ],
    ],
];
