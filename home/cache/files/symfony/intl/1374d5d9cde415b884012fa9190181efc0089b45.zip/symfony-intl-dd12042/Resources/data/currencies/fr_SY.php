<?php

return [
    'Names' => [
        'SYP' => [
            'LS',
            'livre syrienne',
        ],
    ],
];
