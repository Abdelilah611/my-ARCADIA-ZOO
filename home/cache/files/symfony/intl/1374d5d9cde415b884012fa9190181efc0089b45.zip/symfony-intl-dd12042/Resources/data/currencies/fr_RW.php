<?php

return [
    'Names' => [
        'RWF' => [
            'RF',
            'franc rwandais',
        ],
    ],
];
