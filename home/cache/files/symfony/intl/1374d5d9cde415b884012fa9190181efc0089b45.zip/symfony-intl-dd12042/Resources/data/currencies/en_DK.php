<?php

return [
    'Names' => [
        'DKK' => [
            'kr.',
            'Danish Krone',
        ],
    ],
];
