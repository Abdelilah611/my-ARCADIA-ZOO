<?php

return [
    'Names' => [
        'BRL' => [
            'R$',
            'real brasileño',
        ],
    ],
];
