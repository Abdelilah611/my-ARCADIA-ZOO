<?php

return [
    'Names' => [
        'SOS' => [
            'S',
            'شلن صومالي',
        ],
    ],
];
